﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameTimeScale1 : MonoBehaviour
{
    void Start(){
        Time.timeScale = 1;
    }
}
